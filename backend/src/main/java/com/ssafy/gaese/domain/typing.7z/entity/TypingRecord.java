package com.ssafy.gaese.domain.typing.entity;

import com.ssafy.gaese.domain.typing.dto.TypingRecordDto;
import com.ssafy.gaese.domain.user.entity.User;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;

import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "TypingRecord")
public class TypingRecord
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column
    @CreationTimestamp
    private String date;

    @Column
    private Integer rank;

    @Column
    private Integer typeSpeed;

    @Column(length = 20)
    private String langType;


    public TypingRecordDto toDto(){
        return TypingRecordDto.builder()
                .id(this.id)
                .rank(this.rank)
                .date(this.date)
                .langType(this.langType)
                .typeSpeed(this.typeSpeed)
                .build();
    }


}
