package com.ssafy.gaese.domain.typing.controller;


import com.ssafy.gaese.domain.typing.application.IsPlay;
import com.ssafy.gaese.domain.typing.application.TypingRoomApp;
import com.ssafy.gaese.domain.typing.application.TypingUserApp;
import com.ssafy.gaese.domain.typing.dto.TypingRecordDto;
import com.ssafy.gaese.domain.typing.service.TypingRecordService;
import com.ssafy.gaese.domain.user.repository.UserRepository;
import com.ssafy.gaese.security.model.CustomUserDetails;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/typing")
@RequiredArgsConstructor
public class TypingRecordController {

	@Autowired
	TypingUserApp typingUserApp;

	@Autowired
	TypingRoomApp typingRoomApp;


	//나중에 요청해서 service에 기능 만들어서 쓰는게 좋을듯함
	@Autowired
	UserRepository userRepository;

	@Autowired
	IsPlay isPlay;

	@Autowired
	StringRedisTemplate redisTemplate;

	private final SimpMessageSendingOperations sendingOperations;

	private final TypingRecordService typingRecordService;



	@GetMapping("/record")
	@ApiOperation(value = "typing 게임 기록 조회", notes = "사용자별 알고리즘 게임 기록 조회")
	public ResponseEntity<Page<TypingRecordDto>> recordList(Pageable pageable,
															@AuthenticationPrincipal CustomUserDetails userDetails){
		return ResponseEntity.ok().body(typingRecordService.findTypingRecord(userDetails.getId(),pageable));
	}

	@PostMapping("/test4")
	public ResponseEntity<String> test4()
	{
		Boolean b =isPlay.isPlayCheck("test");
		return new ResponseEntity<String>(b.toString(), HttpStatus.OK);
	}
}

