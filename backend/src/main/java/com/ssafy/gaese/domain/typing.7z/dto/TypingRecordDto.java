package com.ssafy.gaese.domain.typing.dto;

import com.ssafy.gaese.domain.user.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;

import static javax.persistence.FetchType.LAZY;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TypingRecordDto
{

    private Long id;


    private String date;

    private Integer rank;

    private Integer typeSpeed;

    private String langType;

}
