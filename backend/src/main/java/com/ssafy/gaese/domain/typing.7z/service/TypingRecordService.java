package com.ssafy.gaese.domain.typing.service;

import com.ssafy.gaese.domain.typing.common.TypingStaticData;
import com.ssafy.gaese.domain.typing.dto.TypingRecordDto;
import com.ssafy.gaese.domain.typing.dto.TypingRoom;
import com.ssafy.gaese.domain.typing.dto.TypingUser;
import com.ssafy.gaese.domain.typing.entity.TypingRecord;
import com.ssafy.gaese.domain.typing.repository.TypingRecordRepository;
import com.ssafy.gaese.domain.typing.repository.TypingRoomRepository;
import com.ssafy.gaese.domain.user.exception.UserNotFoundException;
import com.ssafy.gaese.domain.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
public class TypingRecordService {


    private final UserRepository userRepository;

    private final TypingRecordRepository typingRecordRepository;

    private final TypingRoomRepository typingRoomRepository;




    public Page<TypingRecordDto> findTypingRecord(Long userId, Pageable pageable){
        Page<TypingRecord> typingRecords = typingRecordRepository
                .findAllByUser(userRepository.findById(userId).orElseThrow(()->new UserNotFoundException()), pageable);
        Page<TypingRecordDto> typingRecordsDtoPage = typingRecords.map((TypingRecord) -> TypingRecord.toDto());
        return typingRecordsDtoPage;
    }

    public void setTypingRecord(String roomNo)
    {
        LocalDateTime now = LocalDateTime.now();
        String formatedNow = now.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분 ss초"));
        TypingRoom room = typingRoomRepository.findById(roomNo).get();

        for (TypingUser tu:room.getUsers())
        {
            TypingRecord typingRecord = new TypingRecord();
            typingRecord.setDate(formatedNow);
            typingRecord.setId(tu.getId());
            typingRecord.setLangType(room.getLang());
            typingRecord.setRank(tu.getRank());
            typingRecord.setUser(userRepository.findById(tu.getId()).get());
            typingRecord.setTypeSpeed(tu.getTypeSpeed());

            typingRecordRepository.save(typingRecord);
        }
    }


}
