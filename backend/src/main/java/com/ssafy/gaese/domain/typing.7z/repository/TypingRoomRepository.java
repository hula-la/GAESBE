package com.ssafy.gaese.domain.typing.repository;

import com.ssafy.gaese.domain.typing.dto.TypingRoom;
import org.springframework.data.repository.CrudRepository;

public interface TypingRoomRepository extends CrudRepository<TypingRoom,String> {

}
