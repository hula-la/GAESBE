package com.ssafy.gaese.domain.typing.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TypingPlayingRoomDto {
    String roomNo;
    String roomCode;
    String lang;
    List<String> content;

    Integer startTime;

    List<TypingPlayingRoomDto> users;

}
